package com.example.domain.entity.meals

data class MealsModelResponse(
    val categories: List<Category>
)